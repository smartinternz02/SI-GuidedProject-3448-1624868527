from flask import Flask, request, jsonify, render_template
from tensorflow.keras.models import load_model 
import joblib
import random
import numpy as np
import pickle
import joblib
app = Flask(__name__)

model = load_model("engine.h5")
sc = joblib.load("engine")

#for manual prediction
@app.route('/m_predict')
def predict():
	return render_template('Manual_predict.html')

@app.route('/s_predict')
def spredict():
	return render_template('Sensor_predict.html')

@app.route('/y_predict', methods = ['POST'])
def y_predict():
	x_test = [[int(x) for x in request.form.values()]]
	print(x_test)
	a = model.predict(sc.fit_transform(x_test))
	print(a)
	pred = a[0][0]
	print(pred)
	if (pred < 0.5):
		pred = "No failure expected within 30 days."
	else:
		pred = "Maintenance Required!!! Expected a failure within 30 days."

	return render_template('Manual_predict.html', prediction_text = pred)

#for automatic prediction
@app.route('/sy_predict', methods = ['POST'])
def sy_predict():
	inp1 = []
	inp1.append(random.randint(0,259))
	inp1.append(random.randint(0,365))
	for i in range(0,24):
		inp1.append(random.uniform(-5,5000))
	print(inp1)

	a = model.predict(sc.fit_transform([inp1]))
	print(a)
	pred = a[0][0]
	print(pred)
	if (pred < 0.5):
		pred = "No failure expected within 30 days."
	else:
		pred = "Maintenance Required!!! Expected a failure within 30 days."

	return render_template('Sensor_predict.html', prediction_text = pred, data = inp1)

if __name__ == '__main__':
	app.run(debug = True)
